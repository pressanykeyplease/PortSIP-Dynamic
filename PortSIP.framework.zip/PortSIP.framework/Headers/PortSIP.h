//
//  PortSIP.h
//  PortSIP
//
//  Created by Kaller on 14.07.23.
//

#import <Foundation/Foundation.h>
#import <PortSIP/PortSIPErrors.hxx>
#import <PortSIP/PortSIPTypes.hxx>
#import <PortSIP/PortSIPSDK.h>
#import <PortSIP/PortSIPVideoRenderView.h>
#import <PortSIP/PortSIPEventDelegate.h>

//! Project version number for PortSIP.
FOUNDATION_EXPORT double PortSIPVersionNumber;

//! Project version string for PortSIP.
FOUNDATION_EXPORT const unsigned char PortSIPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PortSIP/PublicHeader.h>

@interface PortSIPTest : NSObject

+ (void)testPortSIP;

@end
